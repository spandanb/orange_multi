var savi, wanlist= new Array(), vmlist= new Array(), cregion, cwan, ctenant;

$(document).ready(function(){
	pageInit();
	$("#servers").on("click", "button.add-node", function(){
		var ip = $(this).attr("id");
		var done = false;
		var ip;
		var nodeName;
		var server;
		for (j=0; j < vmlist.length; j++){
			var server = vmlist[j];
			if (vmlist[j].ip==ip){
				mac = server["mac"];
				nodeName = server["name"];
				server = vmlist[j]
			}
		}
		bootbox.confirm('Are you sure you want to add '+mac+' to the WAN:'+cwan+'?', function(result) {
			if(result){
				showLoading("Wiring up");
				$.get("/l2wan/addnode/?mac="+mac+"&ip="+ip+"&region="+cregion+"&name="+nodeName+"&wan="+cwan+"&tenant="+ctenant, function(data, status){
					if (data == "success"){
						showWANs(ctenant, cwan);
						showVMs(ctenant, cregion);
					}
				});
			}
		}); 
	});
	
	$("#nodes").on("click", "button.remove-node", function(){
		var mac = $(this).attr("id");
		var ip;
		var nodeName;
		for (j=0; j < vmlist.length; j++){
			var server = vmlist[j];
			if (vmlist[j].mac==mac){
				ip = server["ip"];
				nodeName = server["name"];
				break;
			}
		}
		bootbox.confirm('Are you sure you want to remove '+mac+' from the WAN:'+cwan+'?', function(result) {
			if(result){
				$.get("/l2wan/removenode/?mac="+mac+"&ip="+ip+"&region="+cregion+"&name="+nodeName+"&wan="+cwan, function(data, status){
					if (data == "success"){
						showWANs(ctenant, cwan);
						showVMs(ctenant, cregion);
					}
				});
			}
		});
	});	
	
	$("#regions").on("click", "li.region-item", function(){
		var regName = $(this).text();
		if (regName !=cregion){
			cregion = regName;
			showVMs(ctenant, cregion);
		}
	});
	
	$("#projects").on("click", "li.project-item", function(){
		var prName = $(this).text();
		if (prName !=ctenant){
			ctenant = prName;
			$("#projects-title").text(ctenant);
			showWANs(ctenant, null);
			showVMs(ctenant, cregion);
		}
	});
	
	$("#wans").on("click", "li.wan-item", function(){
		var wanName = $(this).text();
		if (wanName != cwan){
			cwan = wanName;
			console.log("wan clicked "+ctenant+" "+cwan);
			showWANs(ctenant, cwan);
		}
	});
	
	$("#add-wan").click(function(){
		newName = $("#add-wan-name").val();
		ipforward = $("#ipforward").val();
		showLoading("Adding new WAN: "+newName);
		$.get("/l2wan/addwan/?new="+newName+"&ip="+ipforward+"&tenant="+ctenant, function(data, status){
			if (data == "success"){
				showWANs(ctenant, newName);
				showSuccess("Success");
			} else if (data == "duplicate"){
				//TO DO: Show Faile.
				showSuccess("Failed: Duplicate WAN name");
			}
		});
	});
	
	$("#sout").click(function(){
		$.ajax({url:"/sout/", success: function(data){
			window.location.href="http://"+window.location.href.split("/")[2];
		}});
	});
	
});

function showWANs(tenant, iwan){
	showLoading("Loading WANs");
	$.getJSON("/l2wan/getwans?tenant="+tenant, function(resp){
		$("#wans").empty();
		$("#nodes").empty();
		$("#wans-title").text("WANs");
	    wanlist = resp;
		for (i=0; i< wanlist.length; i++){
			var wan = wanlist[i];
			if (iwan == null){
				if(i==0){
					wan = wanlist[i];
					$("#wans-title").text(wan.name);
					cwan = wan.name;
					for (j=0; j< wan.servers.length; j++){
						var node = wan.servers[j];
						$("#nodes").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td>"+node.mac+"</td><td><button type=\"button\" class=\"btn btn-sm btn-danger remove-node\" id = \""+node.mac+"\">Remove</button></td></tr>");
					}
				}
			}
			else{
				if (wan.name == iwan){
					$("#wans-title").text(iwan);
					cwan = iwan;
					for (j=0; j< wan.servers.length; j++){
						var node = wan.servers[j];
						$("#nodes").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td>"+node.mac+"</td><td><button type=\"button\" class=\"btn btn-sm btn-danger remove-node\" id = \""+node.mac+"\">Remove</button></td></tr>");
					}
				}
			}			
			$("#wans").append("<li class=\"wan-item\"><a href=\"#\">"+wan.name+"</a></li>");
		}
		if (wan != null)
		showSuccess("Success");
	});
}

function showVMs(tenant, region){
	showLoading("Loading VMs");
	$("#servers").empty();
	$("#regions-title").text(region);
	$.getJSON("/l2wan/getvms?tenant="+tenant+"&region="+region, function(resp){
	    vmlist = resp;
		for (j=0; j < vmlist.length; j++){
			var server = vmlist[j];
			var found = false;
			for (k=0; k<wanlist.length; k++){
				if(wanlist[k].name==cwan)
					for (l=0; l<wanlist[k].servers.length; l++){
						if (wanlist[k].servers[l].ip == server.ip){
							found = true;
							break;
						}
					}
			}
			if(found)
				$("#servers").append("<tr id=\""+server.name+"\"><td>"+server.name+"</td><td>"+server.ip+"</td><td>"+server.mac+"</td><td><button type=\"button\" class=\"btn btn-sm btn-primary disabled add-node\" id = \""+server.ip+"\">Add</button></td></tr>");
			else 
				$("#servers").append("<tr id=\""+server.name+"\"><td>"+server.name+"</td><td>"+server.ip+"</td><td>"+server.mac+"</td><td><button type=\"button\" class=\"btn btn-sm btn-primary add-node\" id = \""+server.ip+"\">Add</button></td></tr>");
		}
		showSuccess("Success");
	});
	
}

function pageInit(){
	//Loading Projects and Regions
	//Loading vms for default region and first project
	//Loading WANs for the first tenant
	showLoading("Loading Projects");
   $.getJSON("/l2wan/getregions/", function(resp){
	    savi = resp;
        for (i=0; i < savi.length; i++){
			var tenant = savi[i];
			if (i==0){
				$("#projects-title").text(tenant.tenant_name);
				ctenant= tenant.tenant_name;
				console.log(ctenant);
				for (j=0; j < tenant.regions.length; j++){
					var region = tenant.regions[j];
					if (j==0){
						$("#regions-title").text(region);
						cregion= region;
						console.log(cregion);
					}
					$("#regions").append("<li class=\"region-item\"><a href=\"#\">"+region+"</a></li>");
				}
			}
			$("#projects").append("<li class=\"project-item\"><a href=\"#\">"+tenant.tenant_name+"</a></li>");
		}
		showSuccess("Success");
		showWANs(ctenant);
		console.log("wans done");
		showVMs(ctenant, cregion);
    });
}

function showLoading(mes){
		$("#loading").css({"display":"block", "background-color":"#E1F5FE", "border-color":"#01579B"});
		$("div.cssload-container").css({"display":"block"});
		$("#loading-holder").css({"display":"none"});
		$("#l-message").text(mes);
		$("#l-message").attr("class", "text-primary");
}

function showSuccess(mes){
		$("#loading").css({"display":"block"});
		$("div.cssload-container").css({"display":"none"});
		$("#loading-holder").css({"display":"block"});
		$("#l-message").text(mes);
		$("#l-message").attr("class", "text-success");
		$("#loading").delay(1000).fadeOut(2000);
}