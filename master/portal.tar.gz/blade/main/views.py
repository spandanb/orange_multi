from django.shortcuts import render, redirect

import httplib
import json
import traceback
from httplib import HTTPException

host = 'iam.savitestbed.ca'
janusPort = 8091
keyPort = 5000
admins= ["hadi", "thomas"]

def main(request):
    if request.method != 'POST':
            return render(request, 'main/chaining.html')
        
        
def _HTTPCall(host, port, method, url, header, body=None):
    
    res = None
    try:
        _conn = httplib.HTTPConnection(host, port)
        header['Content-Type']= "application/json"
        _conn.request(method, url, body=body, headers=header)
        res = _conn.getresponse()
        ret = res.read()
    except:    
        traceback.print_exc()
        pass
    if res.status in (httplib.OK,
                      httplib.CREATED,
                      httplib.ACCEPTED,
                      httplib.NO_CONTENT):
        return ret

    raise httplib.HTTPException(
        res, 'code %d reason %s' % (res.status, res.reason),
        res.getheaders(), res.read())
        
