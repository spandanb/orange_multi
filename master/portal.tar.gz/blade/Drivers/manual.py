'''
Created on Jan 18, 2016

@author: Saeed
'''
from JanusDriver import JanusClient
from GeniDriver import GeniClient
#from L2WAN.controllers.WANController import WANController
import json
import datetime
import isodate

regionTunnelPorts = {"EDGE-WT-1":5051, "EDGE-CT-1":5052, "EDGE-YK-1":5053, "CORE":5054, "EDGE-VC-1":5055, "EDGE-TR-1":5056}
regionDPIDs = {"EDGE-WT-1":"0000089e016163c8", "EDGE-CT-1":"0000192168010003", "EDGE-YK-1":"0000192168001002", "CORE":"0000010010020093", "EDGE-VC-1":"0000192168003020", "EDGE-TR-1":"0000010010030073"}
ORIONPorts = {"EDGE-WT-1":1, "EDGE-CT-1":51, "EDGE-YK-1":18, "EDGE-VC-1":20,  "CORE":52, "EDGE-TR-1":37, "CORE2EDGE-TR-1":37}
network_id_orion='__ORION__'
janus = JanusClient(regionTunnelPorts)
geni = GeniClient()
region= "CORE"
#wan_ctrl = WANController()
def getDuration(datestr):
    date = isodate.parse_datetime(datestr)
    delta = datetime.datetime.now() - date.replace(tzinfo=None)
    return delta.days
    
if __name__ == '__main__':
    janus.setRegion(region)
#     print janus.getPath("fa:16:3e:cf:e7:49", "A0:A0:A0:A0:A0:A0")
    print janus.suggestPath("a0:a0:a0:a0:a0:a0", "fa:16:3e:cf:e7:49")
    #path = res["path"][1]
    #for hop in path:
    #    print hex(hop[0]).rstrip("L")
    #janus.setupPortMacIP(network_id_orion, regionDPIDs[region], "A0:A0:A0:A0:A0:A0",
    #                          "192.168.1.1", ORIONPorts[region], port_type = 'NORMAL')
    
    #print janus.getInfo("10.6.1.5")
    
    #janus.unSetupPortMac(network_id_orion, regionDPIDs[region], ORIONPorts[region], "fa:16:3e:b4:d1:88")  
#     print janus.getFlow("L2WAN_1fa:16:36:4d:99:82fa:16:3e:ed:3d:ae")
    #print "-----------------"
    #print janus.getFlow("L2myWANfa:16:36:20:fc:c8fa:16:3e:b4:d1:88")
#     janus.delFlow("L2WAN_1fa:16:36:4d:99:82fa:16:3e:ed:3d:ae")
#     print getDuration("2015-07-02T18:46:08Z")
#     geni.setOmniPath("/home/ubuntu/blade/.user-info/geni/saeed.a")
#     geni.getResources("SAVI_Main", "saomni", "max-ig")
#     geni.getAdapterInfo("pcvm2-17.instageni.cenic.net", "saeedare", "1990saeed")
