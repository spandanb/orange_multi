import httplib
import json
from NeutronDriver import NeutronClient

class JanusClient(object):
    
    def __init__(self):
        self.port = 8091

    def setRegion(self, region):
        self.region= region
        
        
    def _sendRequest(self, method, url, body = None, headers = {}):
        conn = httplib.HTTPConnection("localhost", self.port)
        conn.request(method, url, body, headers)
        res = conn.getresponse()
        if res.status in (httplib.OK,
                          httplib.CREATED,
                          httplib.ACCEPTED,
                          httplib.NO_CONTENT):
            return res.read()    
        raise httplib.HTTPException(
                res, 'Return status: %d; Reason: %s' % (res.status, res.reason),
                res.getheaders(), res.read())
    
    
    def listNetworks(self):
        self._sendRequest('GET', '/v1.0/network/networks')

    def createNetwork(self, network_id):
        self._sendRequest('POST', '/v1.0/network/networks/%s' % network_id)

    def updateNetwork(self, network_id):
        self._sendRequest('PUT', '/v1.0/network/networks/%s' % network_id)

    def deleteNetwork(self, network_id):
        self._sendRequest('DELETE', '/v1.0/network/networks/%s' % network_id)

    def listPorts(self, network_id):
        self._sendRequest('GET', '/v1.0/network/networks/%s' % network_id)

    def createPort(self, network_id, dpid, port, port_type = 'NORMAL', migrating = 'False'):
        self._sendRequest('POST', '/v1.0/network/networks/%s/%s_%s_%s_%s' % (network_id, dpid, port, port_type, migrating))

    def updatePort(self, network_id, dpid, port):
        self._sendRequest('PUT', '/v1.0/network/networks/%s/%s_%s' % (network_id, dpid, port))

    def deletePort(self, network_id, dpid, port):
        self._sendRequest('DELETE', '/v1.0/network/networks/%s/%s_%s' % (network_id, dpid, port))

    def listMACs(self, network_id):
        self._sendRequest('GET', '/v1.0/network/networks/%s/macs' % network_id)

    def addMAC(self, network_id, mac):
        self._sendRequest('PUT', '/v1.0/network/networks/%s/macs/%s' % (network_id, mac))

    def delMAC(self, network_id, mac):
        self._sendRequest('DELETE', '/v1.0/network/networks/%s/macs/%s' % (network_id, mac))

    def ip_mac_mapping(self, network_id, dpid, mac, ip, port, port_type = 'NORMAL', migrating = 'False'):
        self._sendRequest('PUT', '/v1.0/network/networks/%s/macipportdp/%s/%s/%s_%s_%s_%s' % (network_id, mac, ip, dpid, port, port_type, migrating))

    def lease_remaining(self, network_id, ip_address, mac_address, lease_remaining):
        if lease_remaining == 0:
            self._sendRequest('POST', '/v1.0/network/networks/%s/lease/%s_%s_%s' % (network_id, ip_address, mac_address, lease_remaining))

    def setupPortMacIP(self, network_id, dpid, mac, ip, port, port_type = 'NORMAL', migrating = 'False'):
        self.createPort(network_id, dpid, port, port_type, migrating)
        self.addMAC(network_id, mac)
        self.ip_mac_mapping(network_id, dpid, mac, ip, port, port_type, migrating)

    def unSetupPortMac(self, network_id, dpid, port, mac):
        self.deletePort(network_id, dpid, port)
        self.delMAC(network_id, mac)
        
    def getPath(self, src, dst):
        return self._sendRequest('GET', '/v1.0/network/networks/path/%s_%s' % (src, dst))
    
    def setPath(self, src, dst):
        return self._sendRequest('POST', '/v1.0/network/networks/path/%s_%s' % (src, dst))
    
    def suggestPath(self, src, dst):
        return self._sendRequest('GET', '/v1.0/network/networks/spath/%s_%s' % (src, dst))
    
    def getInfo(self, src):
        return self._sendRequest("GET", '/v1.0/network/networks/info/%s' % (src))
    
    def flushFlows(self, src):
        return self._sendRequest("POST", '/v1.0/network/networks/flush_flows/%s' % (src))
    
    def joinNetworks(self, net_id_a, net_id_b):
        return self._sendRequest("POST",  '/v1.0/network/networks/join/%s_%s' % (net_id_a, net_id_b))
    
    def addFlow(self, dpid, flow):
        return self._sendRequest("POST", '/v1.0/network/networks/user_flow_add/%s' % (dpid), flow, {"Content-Type": "application/json"})
    
    def delFlow(self, label):
        flows = json.loads(self.getFlow(label))
        for i_id, flow in flows.iteritems():
            self.delFlow2(int(flow['datapath_id'],16), label, i_id)
    
    def delFlow2(self, dpid, label, i_id):
        return self._sendRequest("POST", '/v1.0/network/networks/user_flow_del/%s/%s_%s' % (label, dpid, i_id))
    
    def getFlow(self, label):
        return self._sendRequest("GET", '/v1.0/network/networks/user_flow_get/%s' % (label))

class NotJoinedException(Exception):
    def __init__(self, region):
        self.region = region
    pass    
