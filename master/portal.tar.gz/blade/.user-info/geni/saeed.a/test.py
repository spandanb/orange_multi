import subprocess

class geniDriver(object):

	def _subprocess_cmd(command):
    		process = subprocess.Popen(command,stdout=subprocess.PIPE, shell=True)
    		proc_stdout = process.communicate()[0].strip()
    		print proc_stdout

	def omniConfig(path):
	 	commands = ''
                commands += "cd "+path+";"
                commands += "mkdir .gcf; ls;"
                commands += "/usr/local/bin/gcf-2.10/src/omni-configure.py -z omni.bundle -c .gcf/omni-config -p .ssl/geni_cert_portal.pem -k .ssl/geni_ssl_portal.key -s .ssh/"
                _subprocess_cmd(commands)

	def getVMs(path):


	if __name__ == '__main__':
		commands = ''
		commands += "cd /home/ubuntu/blade/.user-info/geni/saeed.a;"
		commands += "mkdir .gcf; ls;"
		commands += "/usr/local/bin/gcf-2.10/src/omni-configure.py -z omni.bundle -c .gcf/omni-config -p .ssl/geni_cert_portal.pem -k .ssl/geni_ssl_portal.key -s .ssh/"
		_subprocess_cmd(commands)
