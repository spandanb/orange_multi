'''
Created on May 26, 2016

@author: Saeed Arezoumand
'''

from KeystoneDriver import KeystoneClient
from NeutronDriver import NeutronClient
import json

host = 'iam.savitestbed.ca'
keystone = KeystoneClient(host)
neutron = NeutronClient(host)

if __name__ == '__main__':
    resp = keystone.getTokensbyUsername("demo2", "saeed.a", "1990saeed")
    token = resp['access']['token']['id']
    print neutron.getGateway(token, "CORE", "demo2")